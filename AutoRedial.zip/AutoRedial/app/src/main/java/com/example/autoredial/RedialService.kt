package com.example.autoredial

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.provider.CallLog
import android.telecom.TelecomManager
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class RedialService : Service() {

    companion object {
        const val EXTRA_NUMBER = "number"
        const val EXTRA_SECONDS = "seconds"
        private const val CHANNEL_ID = "redial"
        private const val NOTIF_ID = 1

        @Volatile var running = false
        @Volatile var attempts = 0
    }

    private val scope = CoroutineScope(Dispatchers.Main)
    private var job: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val number = intent?.getStringExtra(EXTRA_NUMBER) ?: return START_NOT_STICKY
        val seconds = intent.getIntExtra(EXTRA_SECONDS, 22)

        startAsForeground()
        job?.cancel()
        attempts = 0
        running = true

        job = scope.launch {
            while (isActive) {
                attempts++
                val startedAt = System.currentTimeMillis()
                placeCall(number)
                delay(seconds * 1000L)
                endCall()
                delay(2500L) // let the call log entry get written
                if (wasAnswered(startedAt)) {
                    stopSelf() // call was picked up: stop redialing
                    break
                }
            }
        }
        return START_NOT_STICKY
    }

    @SuppressLint("MissingPermission")
    private fun placeCall(number: String) {
        val telecom = getSystemService(TelecomManager::class.java)
        try {
            telecom.placeCall(Uri.fromParts("tel", number, null), null)
        } catch (_: SecurityException) {
            stopSelf()
        }
    }

    // An unanswered outgoing call is logged with duration 0; an answered one has duration > 0.
    @SuppressLint("MissingPermission")
    private fun wasAnswered(since: Long): Boolean {
        return try {
            contentResolver.query(
                CallLog.Calls.CONTENT_URI,
                arrayOf(CallLog.Calls.DURATION),
                "${CallLog.Calls.TYPE} = ? AND ${CallLog.Calls.DATE} >= ?",
                arrayOf(CallLog.Calls.OUTGOING_TYPE.toString(), since.toString()),
                "${CallLog.Calls.DATE} DESC"
            )?.use { c -> c.moveToFirst() && c.getLong(0) > 0 } ?: false
        } catch (_: SecurityException) {
            false
        }
    }

    @SuppressLint("MissingPermission")
    private fun endCall() {
        val telecom = getSystemService(TelecomManager::class.java)
        try {
            telecom.endCall()
        } catch (_: SecurityException) {
            stopSelf()
        }
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Auto Redial", NotificationManager.IMPORTANCE_LOW)
        )
        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Auto Redial running")
            .setContentText("Open the app and tap Stop to end")
            .setSmallIcon(android.R.drawable.sym_action_call)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_PHONE_CALL)
        } else {
            startForeground(NOTIF_ID, notification)
        }
    }

    override fun onDestroy() {
        running = false
        job?.cancel()
        scope.cancel()
        super.onDestroy()
    }
}
