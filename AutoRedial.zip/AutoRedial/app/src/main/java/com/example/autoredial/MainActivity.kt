package com.example.autoredial

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private val handler = android.os.Handler(android.os.Looper.getMainLooper())
    private lateinit var statusText: TextView

    private val refresh = object : Runnable {
        override fun run() {
            statusText.text = if (RedialService.running) {
                "Running: attempt #${RedialService.attempts}"
            } else {
                "Idle (total attempts: ${RedialService.attempts})"
            }
            handler.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val numberInput = findViewById<EditText>(R.id.numberInput)
        val secondsInput = findViewById<EditText>(R.id.secondsInput)
        statusText = findViewById(R.id.statusText)

        findViewById<Button>(R.id.startButton).setOnClickListener {
            val number = numberInput.text.toString().trim()
            val seconds = secondsInput.text.toString().toIntOrNull() ?: 22
            if (number.isEmpty()) {
                Toast.makeText(this, "Enter a number", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (!hasPermissions()) {
                requestPermissions()
                return@setOnClickListener
            }
            val intent = Intent(this, RedialService::class.java).apply {
                putExtra(RedialService.EXTRA_NUMBER, number)
                putExtra(RedialService.EXTRA_SECONDS, seconds.coerceIn(5, 120))
            }
            ContextCompat.startForegroundService(this, intent)
        }

        findViewById<Button>(R.id.stopButton).setOnClickListener {
            stopService(Intent(this, RedialService::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        handler.post(refresh)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(refresh)
    }

    private fun needed(): Array<String> {
        val list = mutableListOf(
            Manifest.permission.CALL_PHONE,
            Manifest.permission.ANSWER_PHONE_CALLS,
            Manifest.permission.READ_CALL_LOG
        )
        if (Build.VERSION.SDK_INT >= 33) list.add(Manifest.permission.POST_NOTIFICATIONS)
        return list.toTypedArray()
    }

    private fun hasPermissions() = needed().all {
        ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestPermissions() {
        ActivityCompat.requestPermissions(this, needed(), 1)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (hasPermissions()) {
            Toast.makeText(this, "Permissions granted. Tap Start again.", Toast.LENGTH_SHORT).show()
        }
    }
}
